<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '7-e$m|~aNl3`:QZ=8c~HKZ=i>Fe*Amw<tf$yd7[=[u@QYDYH{?yoVf{MJN.2S``v');
define('SECURE_AUTH_KEY',  '%%}~ykIlbj265@-*ln9i1XYf>Bv=icb.oSk6AX[6)ekSe~V-v$1w~izLc t-YtcR');
define('LOGGED_IN_KEY',    'tJrB@]6UFNz7XMxm-3eG3<Zez]dwG<eL:g0zp_W{H2l?4jWX1dE$[QgU7f3QVp@G');
define('NONCE_KEY',        'K-.Ki+r]@xs!n:pQY_~Ulps{h*Pt8.(j*s2),pGGJ/N66QQZq@9zlO4PWLP^_}[Q');
define('AUTH_SALT',        '3jNU@1t`gZ5w])Yc o4f]Y}v+;BvMzNUuA4`s6J~,NnZH8dz^}UZp7#I*^;ThUS5');
define('SECURE_AUTH_SALT', 'eH^Jb59x+Ves!=f,Eu>[OA$Jg8 ur}Hf$&u$G%ldbLT|1$jTcxu8+{|JBUPN_c$K');
define('LOGGED_IN_SALT',   'ud@KI2pF=sM@V[R;e;p>TTaS8s9qvhp4IR.w15yJ,1Q/)&wdo7bl^W##63${x2]Z');
define('NONCE_SALT',       '?+6qm:Jncg#aXF+,.3Hk>AymtUQvE7jMzx,//_xK3U?/cP/6K*?Gt8Ko(ahoGY`e');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
