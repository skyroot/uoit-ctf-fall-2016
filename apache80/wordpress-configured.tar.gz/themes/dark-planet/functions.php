<?php

	//Makes the theme widget ready
	if (function_exists('register_sidebar'))
	{
		register_sidebar();
	}
?>