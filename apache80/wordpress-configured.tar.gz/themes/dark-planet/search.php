<?php get_header(); ?>
<div id="wrapper">
	<div id="content">
		<div class="nonpost">
	<?php if (have_posts()) : ?>

		
		<h2>Search Results</h2><br/>
		
		<?php while (have_posts()) : the_post(); ?>
			<div class="post">
				<h2 id="post-<?php the_ID(); ?>"class="posttitle"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
				<small>Posted by <?php the_author_posts_link(); ?> on <?php the_time('jS F , Y') ?> <br /><br/> </small>
				
				<div class="entry">
					<?php the_excerpt() ?>
				</div>
		
					<p class="postmetadata"><?php edit_post_link('Edit','','&nbsp;'); ?> <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?><br/>
						Listed in <?php the_category(', ') ?></p>
			</div>
	
		<?php endwhile; ?>

		<div class="browse">
			<div class="alignleft"><?php next_posts_link('&laquo; Previous Entries') ?></div>
			<div class="alignright"><?php previous_posts_link('Next Entries &raquo;') ?></div>
		</div>
	
	<?php else : ?>

		<h2>Not Found</h2>
		<p class="entrytext" style="padding-bottom:5px">Sorry that search returned no results.</p>
		<?php include (TEMPLATEPATH . '/searchform.php'); ?>

	<?php endif; ?>
	</div>
	</div>

<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>