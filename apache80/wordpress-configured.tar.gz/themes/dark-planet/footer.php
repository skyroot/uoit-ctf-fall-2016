<br class="clear" />
<hr />
</div>
<div id="footer">

	<div id="links">
		<a href="<?php bloginfo('siteurl');?>/" title="<?php bloginfo('name');?>"><?php bloginfo('name');?></a> 
		&copy; <?php echo date('Y');?> All Rights Reserved. <br/>
		
	</div>
   
	<div id="top">
		<a href="#header">Back to Top</a>
	</div>
    
    <br/>
    <div class="footer-small">
    	Wordpress Theme By <a href="http://www.theme-time.com">Theme Time</a>
    </div>
    
    
    
    
</div>


		<?php wp_footer(); ?>

</body>
</html>