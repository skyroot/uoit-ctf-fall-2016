	<div id="sidebar">
		<ul>
			
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
			
			<li id="calendar"><h2>Calendar</h2>
				<?php get_calendar(2); ?>
			</li>
			
			<li id="categories"><h2>Categories</h2>
				<ul class="arrow">
					<?php wp_list_cats('sort_column=name&optioncount=0&hierarchical=0'); ?>
				</ul>
			</li>

			<li id="archives"><h2>Archives</h2>
				<ul class="arrow">
				<?php wp_get_archives('type=monthly'); ?>
				</ul>
			</li>

			

			<?php /* If this is the frontpage */ if ( is_home() || is_page() ) { ?>
			  <li id="blogroll"><h2>Blogroll</h2>
				<ul class="arrow">
					<?php get_links(-1, '<li>', '</li>', ' - '); ?>
				</ul></li>
				
				<li><h2>Meta</h2>
				<ul class="arrow">
					<?php wp_register(); ?>
					<li><?php wp_loginout(); ?></li>
					<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
					<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
					<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
					<?php wp_meta(); ?>
				</ul>
				</li>
			<?php } ?>
			
			<?php endif; ?>
			
		</ul>
	</div>

