<?php
/**
 * Template Name:User track management.
 *
 * @package SweetRice
 * @Dashboard core
 * @since 0.5.4
 */
 defined('VALID_INCLUDE') or die();
 $top_word = _t('Chart');
 $inc = 'view_track.php';
?>