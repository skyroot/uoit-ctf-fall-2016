-- MySQL dump 10.13  Distrib 5.5.53, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: sweetrice
-- ------------------------------------------------------
-- Server version	5.5.53-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `v_attachment`
--

DROP TABLE IF EXISTS `v_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v_attachment` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `post_id` int(10) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `date` int(10) NOT NULL,
  `downloads` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v_attachment`
--

LOCK TABLES `v_attachment` WRITE;
/*!40000 ALTER TABLE `v_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `v_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v_category`
--

DROP TABLE IF EXISTS `v_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v_category` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `link` varchar(128) NOT NULL,
  `title` text NOT NULL,
  `description` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `sort_word` text NOT NULL,
  `parent_id` int(10) NOT NULL DEFAULT '0',
  `template` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `link` (`link`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v_category`
--

LOCK TABLES `v_category` WRITE;
/*!40000 ALTER TABLE `v_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `v_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v_comment`
--

DROP TABLE IF EXISTS `v_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v_comment` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `website` varchar(255) NOT NULL,
  `info` text NOT NULL,
  `post_id` int(10) NOT NULL DEFAULT '0',
  `post_name` varchar(255) NOT NULL,
  `post_cat` varchar(128) NOT NULL,
  `post_slug` varchar(128) NOT NULL,
  `date` int(10) NOT NULL DEFAULT '0',
  `ip` varchar(39) NOT NULL DEFAULT '',
  `reply_date` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v_comment`
--

LOCK TABLES `v_comment` WRITE;
/*!40000 ALTER TABLE `v_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `v_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v_item_data`
--

DROP TABLE IF EXISTS `v_item_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v_item_data` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `item_id` int(10) NOT NULL,
  `item_type` varchar(255) NOT NULL,
  `data_type` varchar(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `item_type` (`item_type`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v_item_data`
--

LOCK TABLES `v_item_data` WRITE;
/*!40000 ALTER TABLE `v_item_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `v_item_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v_item_plugin`
--

DROP TABLE IF EXISTS `v_item_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v_item_plugin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `item_id` int(10) NOT NULL,
  `item_type` varchar(255) NOT NULL,
  `plugin` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v_item_plugin`
--

LOCK TABLES `v_item_plugin` WRITE;
/*!40000 ALTER TABLE `v_item_plugin` DISABLE KEYS */;
INSERT INTO `v_item_plugin` VALUES (1,1,'post','');
/*!40000 ALTER TABLE `v_item_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v_links`
--

DROP TABLE IF EXISTS `v_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v_links` (
  `lid` int(10) NOT NULL AUTO_INCREMENT,
  `request` text NOT NULL,
  `url` text NOT NULL,
  `plugin` varchar(255) NOT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v_links`
--

LOCK TABLES `v_links` WRITE;
/*!40000 ALTER TABLE `v_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `v_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v_options`
--

DROP TABLE IF EXISTS `v_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v_options` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `date` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v_options`
--

LOCK TABLES `v_options` WRITE;
/*!40000 ALTER TABLE `v_options` DISABLE KEYS */;
INSERT INTO `v_options` VALUES (1,'global_setting','a:24:{s:4:\"name\";s:24:\"Galactica Food Store CMS\";s:6:\"author\";s:5:\"adama\";s:5:\"title\";s:0:\"\";s:8:\"keywords\";s:8:\"Keywords\";s:11:\"description\";s:11:\"Description\";s:14:\"admin_priority\";i:0;s:5:\"admin\";s:5:\"adama\";s:6:\"passwd\";s:32:\"b0f8b49f22c718e9924f5b1165111a67\";s:5:\"close\";i:0;s:9:\"close_tip\";s:454:\"<p>Welcome to SweetRice - Thank your for install SweetRice as your website management system.</p><h1>This site is building now , please come late.</h1><p>If you are the webmaster,please go to Dashboard -> General -> Website setting </p><p>and uncheck the checkbox \"Site close\" to open your website.</p><p>More help at <a href=\"http://www.basic-cms.org/docs/5-things-need-to-be-done-when-SweetRice-installed/\">Tip for Basic CMS SweetRice installed</a></p>\";s:5:\"cache\";i:0;s:13:\"cache_expired\";i:0;s:10:\"header_304\";i:0;s:10:\"user_track\";i:0;s:11:\"url_rewrite\";i:0;s:9:\"pagebreak\";i:0;s:4:\"logo\";s:0:\"\";s:5:\"theme\";s:0:\"\";s:4:\"lang\";s:9:\"en-us.php\";s:10:\"theme_lang\";s:0:\"\";s:11:\"admin_email\";s:0:\"\";s:12:\"last_setting\";i:1479351432;s:8:\"timeZone\";s:19:\"America/Los_Angeles\";s:12:\"nums_setting\";a:14:{s:14:\"postCategories\";i:10;s:16:\"postUnCategories\";i:10;s:4:\"tags\";i:100;s:12:\"postCategory\";i:15;s:8:\"postHome\";i:15;s:7:\"postTag\";i:10;s:8:\"postPins\";i:12;s:11:\"postRelated\";i:10;s:11:\"postRssfeed\";i:50;s:11:\"commentList\";i:15;s:11:\"commentPins\";i:12;s:22:\"category_link_per_page\";i:50;s:18:\"post_link_per_page\";i:50;s:20:\"custom_link_per_page\";i:50;}}',1479351432),(2,'categories','',1479265420),(3,'links','',1479265420),(4,'tag_posts','a:0:{}',1479265450),(5,'custom_post_field','a:0:{}',1479265450),(6,'custom_setting_field','a:0:{}',1479351432);
/*!40000 ALTER TABLE `v_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v_posts`
--

DROP TABLE IF EXISTS `v_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v_posts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `tags` text NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sys_name` varchar(128) NOT NULL,
  `date` int(10) NOT NULL DEFAULT '0',
  `category` int(10) NOT NULL DEFAULT '0',
  `in_blog` tinyint(1) NOT NULL,
  `views` int(10) NOT NULL,
  `allow_comment` tinyint(1) NOT NULL DEFAULT '1',
  `template` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sys_name` (`sys_name`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v_posts`
--

LOCK TABLES `v_posts` WRITE;
/*!40000 ALTER TABLE `v_posts` DISABLE KEYS */;
INSERT INTO `v_posts` VALUES (1,'Task','Task','Defaceme','Keywords','','Description','task',1479265450,0,1,1,0,'default');
/*!40000 ALTER TABLE `v_posts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-16 21:57:29
