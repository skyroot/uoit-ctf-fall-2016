<?php 
$database_type = 'mysql';
$db_left = 'v';
$db_url = 'localhost';
$db_port = '3306';
$db_name = 'sweetrice';
$db_username = 'root';
$db_passwd = '';
?>